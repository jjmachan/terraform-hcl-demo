from ._internal.frameworks.onnxmlir import load
from ._internal.frameworks.onnxmlir import save
from ._internal.frameworks.onnxmlir import load_runner

__all__ = ["load", "load_runner", "save"]

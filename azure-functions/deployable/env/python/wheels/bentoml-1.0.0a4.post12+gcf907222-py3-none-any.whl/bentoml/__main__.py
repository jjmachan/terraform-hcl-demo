if __name__ == "__main__":
    from bentoml._internal.cli import create_bentoml_cli

    create_bentoml_cli()()

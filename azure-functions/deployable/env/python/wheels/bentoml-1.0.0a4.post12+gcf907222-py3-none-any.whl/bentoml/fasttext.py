# TODO: add fasttext support
